from substitution import *
import sys

for line in sys.stdin:
   print(crackSubstitution(line))
